class task{

    constructor(title,desc,color,date,status,budget)
    {
        this.title = title;
        this.description = desc;
        this.color = color;
        this.date = date;
        this.status = status;
        this.budget = budget;
        this.name = "Dennis";
    }
}